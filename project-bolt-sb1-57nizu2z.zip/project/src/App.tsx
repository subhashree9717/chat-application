import React, { useState, useEffect, useRef } from 'react';
import { 
  Send, 
  Users, 
  MessageCircle, 
  Wifi, 
  WifiOff,
  User
} from 'lucide-react';

interface Message {
  id: string;
  userId: string;
  username: string;
  color: string;
  text: string;
  timestamp: string;
}

interface User {
  id: string;
  username: string;
  color: string;
  isOnline: boolean;
}

interface TypingUser {
  userId: string;
  username: string;
  isTyping: boolean;
}

function App() {
  const [ws, setWs] = useState<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [username, setUsername] = useState('');
  const [hasJoined, setHasJoined] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [onlineUsers, setOnlineUsers] = useState<User[]>([]);
  const [typingUsers, setTypingUsers] = useState<TypingUser[]>([]);
  const [showUsersList, setShowUsersList] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout>();
  const wsRef = useRef<WebSocket | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const connectWebSocket = () => {
    const websocket = new WebSocket('ws://localhost:3001');
    wsRef.current = websocket;
    
    websocket.onopen = () => {
      console.log('Connected to server');
      setIsConnected(true);
      setWs(websocket);
    };
    
    websocket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      switch (data.type) {
        case 'user_info':
          setCurrentUser(data.user);
          break;
          
        case 'message_history':
          setMessages(data.messages);
          break;
          
        case 'new_message':
          setMessages(prev => [...prev, data.message]);
          break;
          
        case 'users_update':
          setOnlineUsers(data.users);
          break;
          
        case 'user_joined':
          // Could show a notification here
          break;
          
        case 'user_left':
          // Could show a notification here
          break;
          
        case 'user_typing':
          setTypingUsers(prev => {
            const filtered = prev.filter(u => u.userId !== data.userId);
            if (data.isTyping) {
              return [...filtered, { userId: data.userId, username: data.username, isTyping: true }];
            }
            return filtered;
          });
          break;
      }
    };
    
    websocket.onclose = () => {
      console.log('Disconnected from server');
      setIsConnected(false);
      setWs(null);
      // Attempt to reconnect after 3 seconds
      setTimeout(() => {
        if (!wsRef.current || wsRef.current.readyState === WebSocket.CLOSED) {
          connectWebSocket();
        }
      }, 3000);
    };
    
    websocket.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
  };

  useEffect(() => {
    connectWebSocket();
    
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  const joinChat = () => {
    if (!username.trim() || !ws) return;
    
    const userId = Date.now().toString();
    ws.send(JSON.stringify({
      type: 'user_join',
      userId,
      username: username.trim()
    }));
    
    setHasJoined(true);
  };

  const sendMessage = () => {
    if (!inputMessage.trim() || !ws) return;
    
    ws.send(JSON.stringify({
      type: 'send_message',
      text: inputMessage.trim()
    }));
    
    setInputMessage('');
    
    // Stop typing indicator
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    ws.send(JSON.stringify({ type: 'typing_stop' }));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputMessage(e.target.value);
    
    if (!ws) return;
    
    // Send typing start
    ws.send(JSON.stringify({ type: 'typing_start' }));
    
    // Clear existing timeout
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    
    // Set timeout to stop typing
    typingTimeoutRef.current = setTimeout(() => {
      ws.send(JSON.stringify({ type: 'typing_stop' }));
    }, 1000);
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour12: true,
      hour: 'numeric',
      minute: '2-digit'
    });
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  if (!hasJoined) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageCircle className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Join the Chat</h1>
            <p className="text-gray-600">Enter your name to start chatting with others</p>
          </div>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-2">
                Your Name
              </label>
              <input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && joinChat()}
                placeholder="Enter your name..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                maxLength={30}
              />
            </div>
            
            <button
              onClick={joinChat}
              disabled={!username.trim() || !isConnected}
              className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors font-medium flex items-center justify-center gap-2"
            >
              {isConnected ? (
                <>
                  <Wifi className="w-4 h-4" />
                  Join Chat
                </>
              ) : (
                <>
                  <WifiOff className="w-4 h-4" />
                  Connecting...
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Sidebar - Users List */}
      <div className={`bg-white border-r border-gray-200 transition-all duration-300 ${
        showUsersList ? 'w-72' : 'w-0 overflow-hidden'
      } lg:w-72`}>
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-gray-600" />
            <h2 className="font-semibold text-gray-800">Online Users ({onlineUsers.length})</h2>
          </div>
        </div>
        
        <div className="p-4 space-y-3 overflow-y-auto max-h-96">
          {onlineUsers.map(user => (
            <div key={user.id} className="flex items-center gap-3">
              <div 
                className="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-medium"
                style={{ backgroundColor: user.color }}
              >
                {getInitials(user.username)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">
                  {user.username}
                  {user.id === currentUser?.id && ' (You)'}
                </p>
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span className="text-xs text-gray-500">Online</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowUsersList(!showUsersList)}
              className="lg:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <Users className="w-5 h-5 text-gray-600" />
            </button>
            <div>
              <h1 className="text-xl font-semibold text-gray-900">Chat Room</h1>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                {isConnected ? (
                  <>
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    Connected
                  </>
                ) : (
                  <>
                    <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                    Disconnected
                  </>
                )}
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <div 
              className="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-medium"
              style={{ backgroundColor: currentUser?.color }}
            >
              {currentUser && getInitials(currentUser.username)}
            </div>
            <span className="text-sm font-medium text-gray-700 hidden sm:block">
              {currentUser?.username}
            </span>
          </div>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map(message => (
            <div
              key={message.id}
              className={`flex gap-3 ${
                message.userId === currentUser?.id ? 'flex-row-reverse' : ''
              }`}
            >
              <div 
                className="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-medium flex-shrink-0 mt-1"
                style={{ backgroundColor: message.color }}
              >
                {getInitials(message.username)}
              </div>
              
              <div className={`flex-1 max-w-xs sm:max-w-md ${
                message.userId === currentUser?.id ? 'text-right' : ''
              }`}>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm font-medium text-gray-700">
                    {message.username}
                  </span>
                  <span className="text-xs text-gray-500">
                    {formatTime(message.timestamp)}
                  </span>
                </div>
                
                <div className={`rounded-2xl px-4 py-2 ${
                  message.userId === currentUser?.id
                    ? 'bg-blue-600 text-white'
                    : 'bg-white border border-gray-200 text-gray-900'
                }`}>
                  <p className="text-sm break-words">{message.text}</p>
                </div>
              </div>
            </div>
          ))}
          
          {/* Typing Indicators */}
          {typingUsers.filter(u => u.userId !== currentUser?.id).map(user => (
            <div key={user.userId} className="flex items-center gap-2 text-sm text-gray-500">
              <User className="w-4 h-4" />
              <span>{user.username} is typing...</span>
            </div>
          ))}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="bg-white border-t border-gray-200 p-4">
          <div className="flex gap-3">
            <input
              type="text"
              value={inputMessage}
              onChange={handleInputChange}
              onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
              placeholder="Type your message..."
              className="flex-1 px-4 py-3 border border-gray-300 rounded-full focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
              disabled={!isConnected}
              maxLength={500}
            />
            <button
              onClick={sendMessage}
              disabled={!inputMessage.trim() || !isConnected}
              className="bg-blue-600 text-white p-3 rounded-full hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;