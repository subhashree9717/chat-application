import express from 'express';
import { WebSocketServer } from 'ws';
import http from 'http';
import cors from 'cors';

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

app.use(cors());
app.use(express.json());

// Store connected users and messages
const users = new Map();
const messages = [];
const maxMessages = 100; // Keep last 100 messages

// Generate random colors for users
const colors = [
  '#ef4444', '#f97316', '#eab308', '#22c55e', 
  '#06b6d4', '#3b82f6', '#8b5cf6', '#ec4899'
];

function getRandomColor() {
  return colors[Math.floor(Math.random() * colors.length)];
}

function broadcastToAll(data) {
  wss.clients.forEach(client => {
    if (client.readyState === 1) { // WebSocket.OPEN
      client.send(JSON.stringify(data));
    }
  });
}

function broadcastUserList() {
  const userList = Array.from(users.values()).map(user => ({
    id: user.id,
    username: user.username,
    color: user.color,
    isOnline: true
  }));
  
  broadcastToAll({
    type: 'users_update',
    users: userList
  });
}

wss.on('connection', (ws) => {
  console.log('New client connected');
  
  ws.on('message', (data) => {
    try {
      const message = JSON.parse(data.toString());
      
      switch (message.type) {
        case 'user_join':
          const user = {
            id: message.userId,
            username: message.username,
            color: getRandomColor(),
            ws: ws
          };
          
          users.set(ws, user);
          
          // Send existing messages to new user
          ws.send(JSON.stringify({
            type: 'message_history',
            messages: messages
          }));
          
          // Send user info back
          ws.send(JSON.stringify({
            type: 'user_info',
            user: {
              id: user.id,
              username: user.username,
              color: user.color
            }
          }));
          
          // Broadcast user joined
          broadcastToAll({
            type: 'user_joined',
            user: {
              id: user.id,
              username: user.username,
              color: user.color
            }
          });
          
          broadcastUserList();
          break;
          
        case 'send_message':
          const sender = users.get(ws);
          if (sender) {
            const newMessage = {
              id: Date.now().toString(),
              userId: sender.id,
              username: sender.username,
              color: sender.color,
              text: message.text,
              timestamp: new Date().toISOString()
            };
            
            // Add to messages array
            messages.push(newMessage);
            
            // Keep only last maxMessages
            if (messages.length > maxMessages) {
              messages.shift();
            }
            
            // Broadcast to all clients
            broadcastToAll({
              type: 'new_message',
              message: newMessage
            });
          }
          break;
          
        case 'typing_start':
          const typingUser = users.get(ws);
          if (typingUser) {
            broadcastToAll({
              type: 'user_typing',
              userId: typingUser.id,
              username: typingUser.username,
              isTyping: true
            });
          }
          break;
          
        case 'typing_stop':
          const stoppedTypingUser = users.get(ws);
          if (stoppedTypingUser) {
            broadcastToAll({
              type: 'user_typing',
              userId: stoppedTypingUser.id,
              username: stoppedTypingUser.username,
              isTyping: false
            });
          }
          break;
      }
    } catch (error) {
      console.error('Error processing message:', error);
    }
  });
  
  ws.on('close', () => {
    const user = users.get(ws);
    if (user) {
      users.delete(ws);
      
      broadcastToAll({
        type: 'user_left',
        userId: user.id,
        username: user.username
      });
      
      broadcastUserList();
    }
    console.log('Client disconnected');
  });
  
  ws.on('error', (error) => {
    console.error('WebSocket error:', error);
  });
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});