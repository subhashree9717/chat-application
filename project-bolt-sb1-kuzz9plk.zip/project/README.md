# Real-Time Chat Application

A full-featured real-time chat application built with React, TypeScript, Socket.io, and Supabase.

## Features

- 🔐 **User Authentication** - Secure login/signup with Supabase Auth
- 💬 **Real-time Messaging** - Instant messaging with Socket.io
- 📱 **Responsive Design** - Works perfectly on all devices
- 🎮 **Built-in Games** - Tic-tac-toe and Word Guessing games
- 📁 **File Sharing** - Share images, videos, audio files, and documents
- 😀 **Emoji Support** - Full emoji picker and message reactions
- 👥 **Group Management** - Create public/private channels
- 🔄 **Online Status** - See who's online in real-time
- ⚙️ **User Settings** - Update profile, avatar, and status
- 🎨 **Modern UI** - Beautiful dark theme with animations

## Tech Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS, Lucide Icons
- **Backend**: Node.js, Express, Socket.io
- **Database**: Supabase (PostgreSQL)
- **Storage**: Supabase Storage
- **Auth**: Supabase Auth

## Quick Start

### Prerequisites

- Node.js 18+ 
- NPM or Yarn
- Supabase account

### Setup

1. **Clone and install dependencies**
   ```bash
   npm install
   cd server && npm install && cd ..
   ```

2. **Set up Supabase**
   - Create a new project at [supabase.com](https://supabase.com)
   - Go to Settings > API to get your URL and anon key
   - Run the migration: `supabase/migrations/create_complete_chat_schema.sql`

3. **Environment Variables**
   ```bash
   cp .env.example .env
   ```
   Add your Supabase credentials:
   ```
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   ```

4. **Start the application**
   ```bash
   npm start
   ```
   This runs both frontend (http://localhost:5173) and backend (http://localhost:3001)

## Usage

1. **Sign up/Login** - Create an account or sign in
2. **Join Channels** - Browse and join public channels or create your own
3. **Start Chatting** - Send messages, files, and emojis
4. **Play Games** - Click the game controller icon to start games
5. **Customize Profile** - Update your name, avatar, and status

## Project Structure

```
├── src/
│   ├── components/
│   │   ├── Auth/          # Authentication components
│   │   ├── Chat/          # Chat interface components
│   │   ├── Games/         # Mini-games components
│   │   └── Modals/        # Modal dialogs
│   ├── hooks/             # Custom React hooks
│   ├── lib/               # External service configurations
│   └── types/             # TypeScript type definitions
├── server/                # Node.js backend
└── supabase/
    └── migrations/        # Database schema
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

MIT License - feel free to use this project for personal or commercial purposes.