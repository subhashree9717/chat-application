/*
  # Complete Chat Application Schema

  1. New Tables
    - `app_users` - Simple username/password authentication
    - `channels` - Chat channels (public/private)
    - `messages` - Chat messages with file support
    - `channel_members` - Channel membership tracking
    - `game_sessions` - Game state management

  2. Security
    - Enable RLS on all tables
    - Public access policies for demo purposes
    - Foreign key constraints for data integrity

  3. Performance
    - Indexes on frequently queried columns
    - Optimized for real-time chat operations

  4. Default Data
    - System user and default channels
    - Welcome message to get started
*/

-- Create app_users table (simple auth)
CREATE TABLE IF NOT EXISTS app_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username text UNIQUE NOT NULL,
  password text NOT NULL,
  name text NOT NULL,
  avatar text,
  status text DEFAULT 'online' CHECK (status IN ('online', 'offline', 'away')),
  created_at timestamptz DEFAULT now()
);

-- Create channels table
CREATE TABLE IF NOT EXISTS channels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  description text,
  is_private boolean DEFAULT false,
  creator_id uuid NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content text NOT NULL,
  user_id uuid NOT NULL,
  channel_id uuid NOT NULL,
  message_type text DEFAULT 'text' CHECK (message_type IN ('text', 'image', 'video', 'audio', 'file')),
  file_url text,
  file_name text,
  reactions jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Create channel_members table
CREATE TABLE IF NOT EXISTS channel_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id uuid NOT NULL,
  user_id uuid NOT NULL,
  role text DEFAULT 'member' CHECK (role IN ('owner', 'admin', 'member')),
  joined_at timestamptz DEFAULT now(),
  UNIQUE(channel_id, user_id)
);

-- Create game_sessions table
CREATE TABLE IF NOT EXISTS game_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_type text NOT NULL CHECK (game_type IN ('tic-tac-toe', 'word-guess')),
  players uuid[] NOT NULL,
  game_state jsonb DEFAULT '{}',
  current_player uuid,
  status text DEFAULT 'waiting' CHECK (status IN ('waiting', 'playing', 'finished')),
  winner uuid,
  channel_id uuid NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Add foreign key constraints safely
DO $$
BEGIN
  -- Add channels creator foreign key
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'channels_creator_id_fkey'
    AND table_name = 'channels'
  ) THEN
    ALTER TABLE channels 
    ADD CONSTRAINT channels_creator_id_fkey 
    FOREIGN KEY (creator_id) REFERENCES app_users(id) ON DELETE CASCADE;
  END IF;

  -- Add messages user foreign key
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'messages_user_id_fkey'
    AND table_name = 'messages'
  ) THEN
    ALTER TABLE messages 
    ADD CONSTRAINT messages_user_id_fkey 
    FOREIGN KEY (user_id) REFERENCES app_users(id) ON DELETE CASCADE;
  END IF;

  -- Add messages channel foreign key
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'messages_channel_id_fkey'
    AND table_name = 'messages'
  ) THEN
    ALTER TABLE messages 
    ADD CONSTRAINT messages_channel_id_fkey 
    FOREIGN KEY (channel_id) REFERENCES channels(id) ON DELETE CASCADE;
  END IF;

  -- Add channel_members user foreign key
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'channel_members_user_id_fkey'
    AND table_name = 'channel_members'
  ) THEN
    ALTER TABLE channel_members 
    ADD CONSTRAINT channel_members_user_id_fkey 
    FOREIGN KEY (user_id) REFERENCES app_users(id) ON DELETE CASCADE;
  END IF;

  -- Add channel_members channel foreign key
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'channel_members_channel_id_fkey'
    AND table_name = 'channel_members'
  ) THEN
    ALTER TABLE channel_members 
    ADD CONSTRAINT channel_members_channel_id_fkey 
    FOREIGN KEY (channel_id) REFERENCES channels(id) ON DELETE CASCADE;
  END IF;

  -- Add game_sessions channel foreign key
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'game_sessions_channel_id_fkey'
    AND table_name = 'game_sessions'
  ) THEN
    ALTER TABLE game_sessions 
    ADD CONSTRAINT game_sessions_channel_id_fkey 
    FOREIGN KEY (channel_id) REFERENCES channels(id) ON DELETE CASCADE;
  END IF;
END $$;

-- Enable RLS on all tables
ALTER TABLE app_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE channels ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE channel_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_sessions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for app_users
CREATE POLICY "Users can read all profiles"
  ON app_users
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Users can update own profile"
  ON app_users
  FOR UPDATE
  TO public
  USING (true);

CREATE POLICY "Anyone can insert users"
  ON app_users
  FOR INSERT
  TO public
  WITH CHECK (true);

-- RLS Policies for channels
CREATE POLICY "Anyone can read public channels"
  ON channels
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can create channels"
  ON channels
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Channel creators can update their channels"
  ON channels
  FOR UPDATE
  TO public
  USING (true);

-- RLS Policies for messages
CREATE POLICY "Anyone can read messages"
  ON messages
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can insert messages"
  ON messages
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Users can update own messages"
  ON messages
  FOR UPDATE
  TO public
  USING (true);

-- RLS Policies for channel_members
CREATE POLICY "Anyone can read channel members"
  ON channel_members
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can join channels"
  ON channel_members
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Users can leave channels"
  ON channel_members
  FOR DELETE
  TO public
  USING (true);

-- RLS Policies for game_sessions
CREATE POLICY "Anyone can read game sessions"
  ON game_sessions
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can create game sessions"
  ON game_sessions
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Players can update game sessions"
  ON game_sessions
  FOR UPDATE
  TO public
  USING (true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_messages_channel_id ON messages(channel_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);
CREATE INDEX IF NOT EXISTS idx_channel_members_channel_id ON channel_members(channel_id);
CREATE INDEX IF NOT EXISTS idx_channel_members_user_id ON channel_members(user_id);
CREATE INDEX IF NOT EXISTS idx_app_users_username ON app_users(username);
CREATE INDEX IF NOT EXISTS idx_app_users_status ON app_users(status);

-- Insert default data
INSERT INTO app_users (id, username, password, name, status)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  'system',
  'no-password',
  'System',
  'online'
) ON CONFLICT (username) DO NOTHING;

INSERT INTO channels (id, name, description, is_private, creator_id)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  'general',
  'General discussion channel - Welcome to the chat!',
  false,
  '00000000-0000-0000-0000-000000000001'
) ON CONFLICT (name) DO NOTHING;

INSERT INTO channels (id, name, description, is_private, creator_id)
VALUES (
  '00000000-0000-0000-0000-000000000002',
  'random',
  'Random conversations and off-topic discussions',
  false,
  '00000000-0000-0000-0000-000000000001'
) ON CONFLICT (name) DO NOTHING;

-- Add system user to default channels
INSERT INTO channel_members (channel_id, user_id, role)
VALUES 
  ('00000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000001', 'owner'),
  ('00000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000001', 'owner')
ON CONFLICT (channel_id, user_id) DO NOTHING;

-- Insert welcome message
INSERT INTO messages (id, content, user_id, channel_id, message_type, created_at)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  'Welcome to the chat! 🎉 This is a real-time chat application. Feel free to create new channels, share files, and play games!',
  '00000000-0000-0000-0000-000000000001',
  '00000000-0000-0000-0000-000000000001',
  'text',
  now()
) ON CONFLICT (id) DO NOTHING;