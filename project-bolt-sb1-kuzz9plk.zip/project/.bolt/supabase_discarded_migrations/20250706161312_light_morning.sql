/*
  # Complete Chat Application Schema

  1. New Tables
    - `users`
      - `id` (uuid, primary key) 
      - `email` (text, unique)
      - `name` (text)
      - `avatar` (text, optional)
      - `status` (text, default 'online')
      - `created_at` (timestamp)
    
    - `channels`
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text, optional)
      - `is_private` (boolean, default false)
      - `creator_id` (uuid, foreign key)
      - `created_at` (timestamp)
    
    - `messages`
      - `id` (uuid, primary key)
      - `content` (text)
      - `user_id` (uuid, foreign key)
      - `channel_id` (uuid, foreign key)
      - `message_type` (text, default 'text')
      - `file_url` (text, optional)
      - `file_name` (text, optional)
      - `reactions` (jsonb, default '{}')
      - `created_at` (timestamp)

    - `channel_members`
      - `id` (uuid, primary key)
      - `channel_id` (uuid, foreign key)
      - `user_id` (uuid, foreign key)
      - `role` (text, default 'member')
      - `joined_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their data
    - Add policies for channel access based on membership

  3. Storage
    - Create storage bucket for chat files
    - Set up policies for file uploads
*/

-- Create users table with enhanced profile features
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  name text NOT NULL,
  avatar text,
  status text DEFAULT 'online' CHECK (status IN ('online', 'offline', 'away')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create channels table for group chats
CREATE TABLE IF NOT EXISTS channels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  is_private boolean DEFAULT false,
  creator_id uuid REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create messages table for all message types
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content text NOT NULL,
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  channel_id uuid REFERENCES channels(id) ON DELETE CASCADE,
  message_type text DEFAULT 'text' CHECK (message_type IN ('text', 'image', 'video', 'audio', 'file')),
  file_url text,
  file_name text,
  reactions jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Create channel members table for membership management
CREATE TABLE IF NOT EXISTS channel_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id uuid REFERENCES channels(id) ON DELETE CASCADE,
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  role text DEFAULT 'member' CHECK (role IN ('admin', 'moderator', 'member')),
  joined_at timestamptz DEFAULT now(),
  UNIQUE(channel_id, user_id)
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE channels ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE channel_members ENABLE ROW LEVEL SECURITY;

-- Users policies
CREATE POLICY "Users can read all profiles" ON users
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Users can update own profile" ON users
  FOR UPDATE TO authenticated 
  USING (id = (auth.jwt() ->> 'sub')::uuid);

CREATE POLICY "Users can insert own profile" ON users
  FOR INSERT TO authenticated 
  WITH CHECK (id = (auth.jwt() ->> 'sub')::uuid);

-- Channels policies
CREATE POLICY "Users can read public channels" ON channels
  FOR SELECT TO authenticated USING (NOT is_private);

CREATE POLICY "Users can read private channels they're members of" ON channels
  FOR SELECT TO authenticated USING (
    is_private AND EXISTS (
      SELECT 1 FROM channel_members 
      WHERE channel_id = channels.id AND user_id = (auth.jwt() ->> 'sub')::uuid
    )
  );

CREATE POLICY "Users can create channels" ON channels
  FOR INSERT TO authenticated 
  WITH CHECK (creator_id = (auth.jwt() ->> 'sub')::uuid);

CREATE POLICY "Channel creators can update their channels" ON channels
  FOR UPDATE TO authenticated 
  USING (creator_id = (auth.jwt() ->> 'sub')::uuid);

-- Messages policies
CREATE POLICY "Users can read messages in channels they're members of" ON messages
  FOR SELECT TO authenticated USING (
    EXISTS (
      SELECT 1 FROM channel_members 
      WHERE channel_id = messages.channel_id AND user_id = (auth.jwt() ->> 'sub')::uuid
    ) OR EXISTS (
      SELECT 1 FROM channels 
      WHERE id = messages.channel_id AND NOT is_private
    )
  );

CREATE POLICY "Users can send messages to channels they're members of" ON messages
  FOR INSERT TO authenticated WITH CHECK (
    user_id = (auth.jwt() ->> 'sub')::uuid AND (
      EXISTS (
        SELECT 1 FROM channel_members 
        WHERE channel_id = messages.channel_id AND user_id = (auth.jwt() ->> 'sub')::uuid
      ) OR EXISTS (
        SELECT 1 FROM channels 
        WHERE id = messages.channel_id AND NOT is_private
      )
    )
  );

CREATE POLICY "Users can update their own messages" ON messages
  FOR UPDATE TO authenticated 
  USING (user_id = (auth.jwt() ->> 'sub')::uuid);

-- Channel members policies
CREATE POLICY "Users can read channel memberships" ON channel_members
  FOR SELECT TO authenticated USING (
    user_id = (auth.jwt() ->> 'sub')::uuid OR EXISTS (
      SELECT 1 FROM channel_members cm 
      WHERE cm.channel_id = channel_members.channel_id AND cm.user_id = (auth.jwt() ->> 'sub')::uuid
    )
  );

CREATE POLICY "Users can join public channels" ON channel_members
  FOR INSERT TO authenticated WITH CHECK (
    user_id = (auth.jwt() ->> 'sub')::uuid AND EXISTS (
      SELECT 1 FROM channels 
      WHERE id = channel_id AND NOT is_private
    )
  );

CREATE POLICY "Channel admins can manage members" ON channel_members
  FOR ALL TO authenticated USING (
    EXISTS (
      SELECT 1 FROM channel_members cm 
      WHERE cm.channel_id = channel_members.channel_id 
      AND cm.user_id = (auth.jwt() ->> 'sub')::uuid 
      AND cm.role IN ('admin', 'moderator')
    )
  );

-- Create storage bucket for chat files
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM storage.buckets WHERE id = 'chat-files') THEN
    INSERT INTO storage.buckets (id, name, public) 
    VALUES ('chat-files', 'chat-files', true);
  END IF;
END $$;

-- Storage policies
DO $$
BEGIN
  -- Check if policies exist before creating them
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Users can upload chat files'
  ) THEN
    EXECUTE 'CREATE POLICY "Users can upload chat files" ON storage.objects
      FOR INSERT TO authenticated WITH CHECK (bucket_id = ''chat-files'')';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Users can read chat files'
  ) THEN
    EXECUTE 'CREATE POLICY "Users can read chat files" ON storage.objects
      FOR SELECT TO authenticated USING (bucket_id = ''chat-files'')';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Users can update their own chat files'
  ) THEN
    EXECUTE 'CREATE POLICY "Users can update their own chat files" ON storage.objects
      FOR UPDATE TO authenticated USING (bucket_id = ''chat-files'' AND owner = (auth.jwt() ->> ''sub''))';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Users can delete their own chat files'
  ) THEN
    EXECUTE 'CREATE POLICY "Users can delete their own chat files" ON storage.objects
      FOR DELETE TO authenticated USING (bucket_id = ''chat-files'' AND owner = (auth.jwt() ->> ''sub''))';
  END IF;
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_messages_channel_created ON messages(channel_id, created_at);
CREATE INDEX IF NOT EXISTS idx_messages_user_created ON messages(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_channel_members_channel ON channel_members(channel_id);
CREATE INDEX IF NOT EXISTS idx_channel_members_user ON channel_members(user_id);

-- Function to automatically add creator as admin when creating a channel
CREATE OR REPLACE FUNCTION add_creator_as_admin()
RETURNS trigger AS $$
BEGIN
  INSERT INTO channel_members (channel_id, user_id, role)
  VALUES (NEW.id, NEW.creator_id, 'admin');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to automatically add creator as admin
DROP TRIGGER IF EXISTS add_creator_as_admin_trigger ON channels;
CREATE TRIGGER add_creator_as_admin_trigger
  AFTER INSERT ON channels
  FOR EACH ROW
  EXECUTE FUNCTION add_creator_as_admin();

-- Function to handle user profile creation
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO users (id, email, name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)));
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for new user registration
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();