export interface User {
  id: string;
  username: string;
  name: string;
  avatar?: string;
  status: 'online' | 'offline' | 'away';
  created_at: string;
}

export interface Message {
  id: string;
  content: string;
  user_id: string;
  channel_id: string;
  message_type: 'text' | 'image' | 'video' | 'audio' | 'file';
  file_url?: string;
  file_name?: string;
  reactions: Record<string, string[]>;
  created_at: string;
  user?: User;
}

export interface Channel {
  id: string;
  name: string;
  description?: string;
  is_private: boolean;
  creator_id: string;
  created_at: string;
  members?: User[];
}

export interface GameSession {
  id: string;
  game_type: 'tic-tac-toe' | 'word-guess';
  players: string[];
  game_state: any;
  current_player: string;
  status: 'waiting' | 'playing' | 'finished';
  winner?: string;
}