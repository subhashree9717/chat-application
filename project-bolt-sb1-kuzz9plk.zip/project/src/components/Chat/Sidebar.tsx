import React, { useState } from 'react';
import { Hash, Plus, Users, Settings, LogOut, Search, User, MessageCircle, Lock } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { Channel, User as UserType } from '../../types';
import { LocalStorage } from '../../lib/storage';

interface SidebarProps {
  channels: Channel[];
  users: UserType[];
  activeChannel?: string;
  onChannelSelect: (channelId: string) => void;
  onCreateChannel: () => void;
  onUserSettings: () => void;
  onStartDirectMessage?: (userId: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  channels,
  users,
  activeChannel,
  onChannelSelect,
  onCreateChannel,
  onUserSettings,
  onStartDirectMessage
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const { user, signOut } = useAuth();

  const filteredChannels = channels.filter(channel =>
    channel.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredUsers = users.filter(u => 
    u.id !== user?.id && (
      u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.username.toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      case 'offline': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusEmoji = (status: string) => {
    switch (status) {
      case 'online': return '🟢';
      case 'away': return '🟡';
      case 'offline': return '⚫';
      default: return '⚫';
    }
  };

  const handleDirectMessage = (targetUser: UserType) => {
    if (onStartDirectMessage) {
      onStartDirectMessage(targetUser.id);
    } else {
      // Create a direct message channel
      const dmChannelId = `dm_${[user?.id, targetUser.id].sort().join('_')}`;
      const existingChannel = channels.find(c => c.id === dmChannelId);
      
      if (!existingChannel) {
        const dmChannel: Channel = {
          id: dmChannelId,
          name: `${targetUser.name}`,
          description: `Direct message with ${targetUser.name}`,
          is_private: true,
          creator_id: user?.id || '',
          created_at: new Date().toISOString()
        };
        
        LocalStorage.addChannel(dmChannel);
        if (user) {
          LocalStorage.addMemberToChannel(dmChannelId, user.id, 'owner');
          LocalStorage.addMemberToChannel(dmChannelId, targetUser.id, 'member');
        }
      }
      
      onChannelSelect(dmChannelId);
    }
  };

  return (
    <div className="w-64 bg-gray-900 border-r border-gray-800 flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-gray-800">
        <h2 className="text-xl font-bold text-white">ChatApp</h2>
      </div>

      {/* Search */}
      <div className="p-4">
        <div className="relative">
          <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search channels & users..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          />
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        {/* Channels */}
        <div className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-medium text-gray-400 uppercase tracking-wider">
              Channels
            </h3>
            <button
              onClick={onCreateChannel}
              className="p-1 hover:bg-gray-800 rounded transition-colors"
              title="Create channel"
            >
              <Plus className="w-4 h-4 text-gray-400" />
            </button>
          </div>
          
          <div className="space-y-1">
            {filteredChannels.map((channel) => (
              <button
                key={channel.id}
                onClick={() => onChannelSelect(channel.id)}
                className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-left transition-colors ${
                  activeChannel === channel.id
                    ? 'bg-purple-600 text-white'
                    : 'text-gray-300 hover:bg-gray-800'
                }`}
              >
                {channel.is_private ? (
                  <Lock className="w-4 h-4" />
                ) : (
                  <Hash className="w-4 h-4" />
                )}
                <span className="truncate">{channel.name}</span>
                {channel.id.startsWith('dm_') && (
                  <MessageCircle className="w-3 h-3 ml-auto" />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Direct Messages */}
        <div className="p-4 border-t border-gray-800">
          <h3 className="text-sm font-medium text-gray-400 uppercase tracking-wider mb-3">
            Direct Messages
          </h3>
          <div className="space-y-2">
            {filteredUsers.map((otherUser) => (
              <button
                key={otherUser.id}
                onClick={() => handleDirectMessage(otherUser)}
                className="w-full flex items-center gap-2 px-2 py-1 hover:bg-gray-800 rounded transition-colors"
              >
                <div className="relative">
                  <div className="w-6 h-6 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center overflow-hidden">
                    {otherUser.avatar ? (
                      <img
                        src={otherUser.avatar}
                        alt={otherUser.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <User className="w-3 h-3 text-white" />
                    )}
                  </div>
                  <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 ${getStatusColor(otherUser.status)} border-2 border-gray-900 rounded-full`} />
                </div>
                <span className="text-sm text-gray-300 truncate">{otherUser.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Online Users */}
      </div>

      {/* User Profile */}
      <div className="p-4 border-t border-gray-800">
        <div className="flex items-center gap-3 mb-3">
          <div className="relative">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center overflow-hidden">
              {user?.avatar ? (
                <img
                  src={user.avatar}
                  alt={user.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <User className="w-4 h-4 text-white" />
              )}
            </div>
            <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 ${getStatusColor(user?.status || 'offline')} border-2 border-gray-900 rounded-full`} />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-white">{user?.name}</p>
            <p className="text-xs text-gray-400 flex items-center gap-1">
              {getStatusEmoji(user?.status || 'offline')} @{user?.username}
            </p>
          </div>
        </div>
        
        <div className="flex gap-2">
          <button
            onClick={onUserSettings}
            className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
          >
            <Settings className="w-4 h-4 text-gray-400" />
            <span className="text-sm text-gray-400">Settings</span>
          </button>
          <button
            onClick={signOut}
            className="flex items-center justify-center p-2 bg-red-600 hover:bg-red-700 rounded-lg transition-colors"
            title="Sign out"
          >
            <LogOut className="w-4 h-4 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
};