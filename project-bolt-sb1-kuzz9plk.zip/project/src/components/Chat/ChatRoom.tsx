import React, { useState, useEffect } from 'react';
import { Sidebar } from './Sidebar';
import { ChatHeader } from './ChatHeader';
import { MessageList } from './MessageList';
import { MessageInput } from './MessageInput';
import { CreateChannelModal } from '../Modals/CreateChannelModal';
import { UserSettingsModal } from '../Modals/UserSettingsModal';
import { ChannelSettingsModal } from '../Modals/ChannelSettingsModal';
import { CallModal } from '../Modals/CallModal';
import { GameModal } from '../Games/GameModal';
import { useAuth } from '../../hooks/useAuth';
import { LocalStorage } from '../../lib/storage';
import { Channel, Message, User } from '../../types';

export const ChatRoom: React.FC = () => {
  const { user } = useAuth();
  const [channels, setChannels] = useState<Channel[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [activeChannel, setActiveChannel] = useState<string>('general');
  const [showCreateChannel, setShowCreateChannel] = useState(false);
  const [showUserSettings, setShowUserSettings] = useState(false);
  const [showChannelSettings, setShowChannelSettings] = useState(false);
  const [showGameModal, setShowGameModal] = useState(false);
  const [showCallModal, setShowCallModal] = useState(false);
  const [callType, setCallType] = useState<'voice' | 'video'>('voice');
  const [callChannelId, setCallChannelId] = useState<string>('');

  useEffect(() => {
    loadChannels();
    loadUsers();
  }, []);

  useEffect(() => {
    if (activeChannel) {
      loadMessages(activeChannel);
    }
  }, [activeChannel]);

  // Auto-refresh data every 2 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      loadMessages(activeChannel);
      loadUsers();
    }, 2000);

    return () => clearInterval(interval);
  }, [activeChannel]);

  const loadChannels = () => {
    const channelData = LocalStorage.getChannels();
    setChannels(channelData);
  };

  const loadMessages = (channelId: string) => {
    const messageData = LocalStorage.getMessages(channelId);
    setMessages(messageData);
  };

  const loadUsers = () => {
    const userData = LocalStorage.getUsers();
    setUsers(userData);
  };

  const handleSendMessage = async (content: string, type: 'text' | 'image' | 'video' | 'audio' | 'file', file?: File) => {
    if (!user || !activeChannel) return;

    let fileUrl = '';
    let fileName = '';

    if (file) {
      // For demo purposes, create a fake URL
      fileUrl = URL.createObjectURL(file);
      fileName = file.name;
    }

    const message: Message = {
      id: Date.now().toString(),
      content,
      user_id: user.id,
      channel_id: activeChannel,
      message_type: type,
      file_url: fileUrl,
      file_name: fileName,
      reactions: {},
      created_at: new Date().toISOString(),
      user: user
    };

    LocalStorage.addMessage(message);
    loadMessages(activeChannel);
  };

  const handleCreateChannel = async (name: string, description: string, isPrivate: boolean) => {
    if (!user) return;

    const channel: Channel = {
      id: Date.now().toString(),
      name,
      description,
      is_private: isPrivate,
      creator_id: user.id,
      created_at: new Date().toISOString()
    };

    LocalStorage.addChannel(channel);
    // Add creator as owner
    LocalStorage.addMemberToChannel(channel.id, user.id, 'owner');
    loadChannels();
    setActiveChannel(channel.id);
  };

  const handleReaction = async (messageId: string, emoji: string) => {
    if (!user) return;

    const message = messages.find(m => m.id === messageId);
    if (!message) return;

    const reactions = { ...message.reactions };
    if (!reactions[emoji]) {
      reactions[emoji] = [];
    }

    const userIndex = reactions[emoji].indexOf(user.id);
    if (userIndex > -1) {
      reactions[emoji].splice(userIndex, 1);
      if (reactions[emoji].length === 0) {
        delete reactions[emoji];
      }
    } else {
      reactions[emoji].push(user.id);
    }

    LocalStorage.updateMessage(messageId, activeChannel, { reactions });
    loadMessages(activeChannel);
  };

  const handleStartCall = (type: 'voice' | 'video', channelId: string) => {
    setCallType(type);
    setCallChannelId(channelId);
    setShowCallModal(true);
  };

  const handleChannelDeleted = () => {
    loadChannels();
    setActiveChannel('general');
  };

  const currentChannel = channels.find(c => c.id === activeChannel);
  const onlineUsers = users.filter(u => u.status === 'online');

  return (
    <div className="flex h-screen bg-gray-900">
      <Sidebar
        channels={channels}
        users={onlineUsers}
        activeChannel={activeChannel}
        onChannelSelect={setActiveChannel}
        onCreateChannel={() => setShowCreateChannel(true)}
        onUserSettings={() => setShowUserSettings(true)}
      />

      <div className="flex-1 flex flex-col">
        <ChatHeader
          channel={currentChannel}
          onlineCount={onlineUsers.length}
          onChannelSettings={() => setShowChannelSettings(true)}
          onStartCall={handleStartCall}
        />

        <MessageList
          messages={messages}
          currentUserId={user?.id || ''}
          onReaction={handleReaction}
        />

        <MessageInput
          onSendMessage={handleSendMessage}
          onStartGame={() => setShowGameModal(true)}
        />
      </div>

      <CreateChannelModal
        isOpen={showCreateChannel}
        onClose={() => setShowCreateChannel(false)}
        onCreate={handleCreateChannel}
      />

      <UserSettingsModal
        isOpen={showUserSettings}
        onClose={() => setShowUserSettings(false)}
      />

      {currentChannel && (
        <ChannelSettingsModal
          isOpen={showChannelSettings}
          onClose={() => setShowChannelSettings(false)}
          channel={currentChannel}
          onChannelUpdated={loadChannels}
          onChannelDeleted={handleChannelDeleted}
        />
      )}

      <CallModal
        isOpen={showCallModal}
        onClose={() => setShowCallModal(false)}
        callType={callType}
        channelName={currentChannel?.name || ''}
        channelId={callChannelId}
      />

      <GameModal
        isOpen={showGameModal}
        onClose={() => setShowGameModal(false)}
      />
    </div>
  );
};