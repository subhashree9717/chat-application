import React, { useState } from 'react';
import { Hash, Users, Settings, Phone, Video, UserPlus, Lock } from 'lucide-react';
import { Channel } from '../../types';
import { MembersModal } from '../Modals/MembersModal';
import { AddMemberModal } from '../Modals/AddMemberModal';

interface ChatHeaderProps {
  channel?: Channel;
  onlineCount: number;
  onChannelSettings: () => void;
  onStartCall?: (type: 'voice' | 'video', channelId: string) => void;
}

export const ChatHeader: React.FC<ChatHeaderProps> = ({
  channel,
  onlineCount,
  onChannelSettings,
  onStartCall
}) => {
  const [showMembers, setShowMembers] = useState(false);
  const [showAddMember, setShowAddMember] = useState(false);

  if (!channel) return null;

  const handleCall = (type: 'voice' | 'video') => {
    if (onStartCall) {
      onStartCall(type, channel.id);
    } else {
      // Fallback notification
      alert(`${type === 'voice' ? 'Voice' : 'Video'} call feature coming soon!`);
    }
  };

  return (
    <>
      <div className="border-b border-gray-800 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gray-800 rounded-lg">
              {channel.is_private ? (
                <Lock className="w-5 h-5 text-gray-400" />
              ) : (
                <Hash className="w-5 h-5 text-gray-400" />
              )}
            </div>
            <div>
              <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                {channel.name}
                {channel.is_private && (
                  <span className="text-xs bg-yellow-600 text-yellow-100 px-2 py-1 rounded-full">
                    Private
                  </span>
                )}
              </h2>
              <p className="text-sm text-gray-400">
                {channel.description || `${onlineCount} members online`}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button 
              onClick={() => handleCall('voice')}
              className="p-2 hover:bg-gray-800 rounded-lg transition-colors group"
              title="Start voice call"
            >
              <Phone className="w-5 h-5 text-gray-400 group-hover:text-green-400" />
            </button>
            <button 
              onClick={() => handleCall('video')}
              className="p-2 hover:bg-gray-800 rounded-lg transition-colors group"
              title="Start video call"
            >
              <Video className="w-5 h-5 text-gray-400 group-hover:text-blue-400" />
            </button>
            <button 
              onClick={() => setShowAddMember(true)}
              className="p-2 hover:bg-gray-800 rounded-lg transition-colors group"
              title="Add member"
            >
              <UserPlus className="w-5 h-5 text-gray-400 group-hover:text-purple-400" />
            </button>
            <button 
              onClick={() => setShowMembers(true)}
              className="p-2 hover:bg-gray-800 rounded-lg transition-colors group"
              title="View members"
            >
              <Users className="w-5 h-5 text-gray-400 group-hover:text-blue-400" />
            </button>
            <button
              onClick={onChannelSettings}
              className="p-2 hover:bg-gray-800 rounded-lg transition-colors group"
              title="Channel settings"
            >
              <Settings className="w-5 h-5 text-gray-400 group-hover:text-gray-300" />
            </button>
          </div>
        </div>
      </div>

      <MembersModal
        isOpen={showMembers}
        onClose={() => setShowMembers(false)}
        channel={channel}
      />

      <AddMemberModal
        isOpen={showAddMember}
        onClose={() => setShowAddMember(false)}
        channel={channel}
      />
    </>
  );
};