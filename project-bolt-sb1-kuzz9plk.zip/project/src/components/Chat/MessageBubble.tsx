import React, { useState } from 'react';
import { User, Heart, ThumbsUp, Laugh, Download, Play } from 'lucide-react';
import { Message } from '../../types';

interface MessageBubbleProps {
  message: Message;
  isOwn: boolean;
  onReaction: (messageId: string, emoji: string) => void;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({
  message,
  isOwn,
  onReaction
}) => {
  const [showReactions, setShowReactions] = useState(false);
  
  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const renderContent = () => {
    switch (message.message_type) {
      case 'image':
        return (
          <div className="max-w-xs">
            <img
              src={message.file_url}
              alt={message.file_name}
              className="rounded-lg max-w-full h-auto"
            />
          </div>
        );
      case 'video':
        return (
          <div className="max-w-xs">
            <video
              src={message.file_url}
              controls
              className="rounded-lg max-w-full h-auto"
            />
          </div>
        );
      case 'audio':
        return (
          <div className="flex items-center gap-2 p-2 bg-gray-100 rounded-lg">
            <Play className="w-4 h-4" />
            <audio src={message.file_url} controls className="max-w-full" />
          </div>
        );
      case 'file':
        return (
          <div className="flex items-center gap-2 p-2 bg-gray-100 rounded-lg">
            <Download className="w-4 h-4" />
            <span className="text-sm">{message.file_name}</span>
          </div>
        );
      default:
        return <p className="text-white">{message.content}</p>;
    }
  };

  const reactions = ['❤️', '👍', '😂', '😮', '😢', '😡'];

  return (
    <div className={`flex ${isOwn ? 'justify-end' : 'justify-start'} group`}>
      <div className={`max-w-xs lg:max-w-md ${isOwn ? 'order-2' : 'order-1'}`}>
        {/* User info */}
        {!isOwn && (
          <div className="flex items-center gap-2 mb-1">
            <div className="w-6 h-6 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center">
              <User className="w-3 h-3 text-white" />
            </div>
            <span className="text-sm text-gray-400">{message.user?.name}</span>
            <span className="text-xs text-gray-500">{formatTime(message.created_at)}</span>
          </div>
        )}

        {/* Message bubble */}
        <div
          className={`relative px-4 py-2 rounded-2xl ${
            isOwn
              ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white'
              : 'bg-gray-700 text-white'
          }`}
          onMouseEnter={() => setShowReactions(true)}
          onMouseLeave={() => setShowReactions(false)}
        >
          {renderContent()}
          
          {/* Reactions */}
          {Object.keys(message.reactions).length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {Object.entries(message.reactions).map(([emoji, users]) => (
                <button
                  key={emoji}
                  onClick={() => onReaction(message.id, emoji)}
                  className="flex items-center gap-1 px-2 py-1 bg-white/10 rounded-full text-xs hover:bg-white/20 transition-colors"
                >
                  <span>{emoji}</span>
                  <span>{users.length}</span>
                </button>
              ))}
            </div>
          )}

          {/* Quick reactions */}
          {showReactions && (
            <div className="absolute top-0 right-0 transform -translate-y-full flex gap-1 p-2 bg-gray-800 rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity">
              {reactions.map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => onReaction(message.id, emoji)}
                  className="w-8 h-8 flex items-center justify-center hover:bg-gray-700 rounded-full transition-colors"
                >
                  {emoji}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Timestamp for own messages */}
        {isOwn && (
          <div className="text-right mt-1">
            <span className="text-xs text-gray-500">{formatTime(message.created_at)}</span>
          </div>
        )}
      </div>
    </div>
  );
};