import React, { useState } from 'react';

export const TicTacToe: React.FC = () => {
  const [board, setBoard] = useState<(string | null)[]>(Array(9).fill(null));
  const [isXNext, setIsXNext] = useState(true);
  const [winner, setWinner] = useState<string | null>(null);

  const checkWinner = (squares: (string | null)[]) => {
    const lines = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6],
    ];
    for (let i = 0; i < lines.length; i++) {
      const [a, b, c] = lines[i];
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        return squares[a];
      }
    }
    return null;
  };

  const handleClick = (index: number) => {
    if (board[index] || winner) return;

    const newBoard = [...board];
    newBoard[index] = isXNext ? 'X' : 'O';
    setBoard(newBoard);
    setIsXNext(!isXNext);

    const gameWinner = checkWinner(newBoard);
    if (gameWinner) {
      setWinner(gameWinner);
    }
  };

  const resetGame = () => {
    setBoard(Array(9).fill(null));
    setIsXNext(true);
    setWinner(null);
  };

  return (
    <div className="text-center">
      <h3 className="text-2xl font-bold text-white mb-4">Tic Tac Toe</h3>
      
      <div className="mb-4">
        {winner ? (
          <p className="text-lg text-green-400">Winner: {winner}!</p>
        ) : board.every(cell => cell) ? (
          <p className="text-lg text-yellow-400">It's a tie!</p>
        ) : (
          <p className="text-lg text-white">Next player: {isXNext ? 'X' : 'O'}</p>
        )}
      </div>

      <div className="grid grid-cols-3 gap-2 w-48 mx-auto mb-4">
        {board.map((cell, index) => (
          <button
            key={index}
            onClick={() => handleClick(index)}
            className="w-16 h-16 bg-gray-700 hover:bg-gray-600 border border-gray-600 rounded-lg text-2xl font-bold text-white transition-colors"
          >
            {cell}
          </button>
        ))}
      </div>

      <button
        onClick={resetGame}
        className="px-6 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
      >
        New Game
      </button>
    </div>
  );
};