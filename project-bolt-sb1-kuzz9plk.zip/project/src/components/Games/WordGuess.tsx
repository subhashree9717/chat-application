import React, { useState, useEffect } from 'react';

const words = [
  'REACT', 'JAVASCRIPT', 'TYPESCRIPT', 'COMPONENT', 'FUNCTION',
  'VARIABLE', 'ARRAY', 'OBJECT', 'STRING', 'NUMBER', 'BOOLEAN',
  'PROMISE', 'ASYNC', 'AWAIT', 'FETCH', 'API', 'STATE', 'PROPS'
];

export const WordGuess: React.FC = () => {
  const [currentWord, setCurrentWord] = useState('');
  const [guessedLetters, setGuessedLetters] = useState<string[]>([]);
  const [wrongGuesses, setWrongGuesses] = useState(0);
  const [gameStatus, setGameStatus] = useState<'playing' | 'won' | 'lost'>('playing');

  const maxWrongGuesses = 6;

  useEffect(() => {
    startNewGame();
  }, []);

  const startNewGame = () => {
    const randomWord = words[Math.floor(Math.random() * words.length)];
    setCurrentWord(randomWord);
    setGuessedLetters([]);
    setWrongGuesses(0);
    setGameStatus('playing');
  };

  const handleLetterGuess = (letter: string) => {
    if (guessedLetters.includes(letter) || gameStatus !== 'playing') return;

    const newGuessedLetters = [...guessedLetters, letter];
    setGuessedLetters(newGuessedLetters);

    if (!currentWord.includes(letter)) {
      const newWrongGuesses = wrongGuesses + 1;
      setWrongGuesses(newWrongGuesses);
      
      if (newWrongGuesses >= maxWrongGuesses) {
        setGameStatus('lost');
      }
    }

    // Check if word is complete
    if (currentWord.split('').every(letter => newGuessedLetters.includes(letter))) {
      setGameStatus('won');
    }
  };

  const displayWord = currentWord
    .split('')
    .map(letter => (guessedLetters.includes(letter) ? letter : '_'))
    .join(' ');

  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  return (
    <div className="text-center">
      <h3 className="text-2xl font-bold text-white mb-4">Word Guess</h3>
      
      <div className="mb-4">
        <div className="text-3xl font-mono text-white mb-2">{displayWord}</div>
        <div className="text-sm text-gray-400">
          Wrong guesses: {wrongGuesses}/{maxWrongGuesses}
        </div>
      </div>

      {gameStatus === 'won' && (
        <div className="mb-4 p-4 bg-green-600 rounded-lg">
          <p className="text-white font-semibold">🎉 Congratulations! You won!</p>
        </div>
      )}

      {gameStatus === 'lost' && (
        <div className="mb-4 p-4 bg-red-600 rounded-lg">
          <p className="text-white font-semibold">💀 Game Over!</p>
          <p className="text-white">The word was: {currentWord}</p>
        </div>
      )}

      <div className="grid grid-cols-6 gap-2 mb-4">
        {alphabet.map(letter => (
          <button
            key={letter}
            onClick={() => handleLetterGuess(letter)}
            disabled={guessedLetters.includes(letter) || gameStatus !== 'playing'}
            className={`w-8 h-8 rounded border text-sm font-semibold transition-colors ${
              guessedLetters.includes(letter)
                ? currentWord.includes(letter)
                  ? 'bg-green-600 text-white border-green-600'
                  : 'bg-red-600 text-white border-red-600'
                : 'bg-gray-700 text-white border-gray-600 hover:bg-gray-600'
            } disabled:cursor-not-allowed`}
          >
            {letter}
          </button>
        ))}
      </div>

      <button
        onClick={startNewGame}
        className="px-6 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
      >
        New Game
      </button>
    </div>
  );
};