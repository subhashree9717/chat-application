import React, { useState } from 'react';
import { X, Gamepad2 } from 'lucide-react';
import { TicTacToe } from './TicTacToe';
import { WordGuess } from './WordGuess';

interface GameModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GameModal: React.FC<GameModalProps> = ({ isOpen, onClose }) => {
  const [selectedGame, setSelectedGame] = useState<string | null>(null);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg p-6 w-full max-w-2xl mx-4 max-h-[80vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-white flex items-center gap-2">
            <Gamepad2 className="w-6 h-6" />
            Games
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        {!selectedGame ? (
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => setSelectedGame('tic-tac-toe')}
              className="p-6 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors text-center"
            >
              <div className="text-4xl mb-2">⭕</div>
              <h3 className="text-lg font-semibold text-white">Tic Tac Toe</h3>
              <p className="text-sm text-gray-400">Classic 3x3 game</p>
            </button>
            <button
              onClick={() => setSelectedGame('word-guess')}
              className="p-6 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors text-center"
            >
              <div className="text-4xl mb-2">📝</div>
              <h3 className="text-lg font-semibold text-white">Word Guess</h3>
              <p className="text-sm text-gray-400">Guess the word</p>
            </button>
          </div>
        ) : (
          <div>
            <button
              onClick={() => setSelectedGame(null)}
              className="mb-4 px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors text-white"
            >
              ← Back to Games
            </button>
            {selectedGame === 'tic-tac-toe' && <TicTacToe />}
            {selectedGame === 'word-guess' && <WordGuess />}
          </div>
        )}
      </div>
    </div>
  );
};