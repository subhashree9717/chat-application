import React, { useState } from 'react';
import { X, Settings, Hash, Lock, Trash2, Save } from 'lucide-react';
import { Channel } from '../../types';
import { LocalStorage } from '../../lib/storage';
import { useAuth } from '../../hooks/useAuth';

interface ChannelSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  channel: Channel;
  onChannelUpdated: () => void;
  onChannelDeleted: () => void;
}

export const ChannelSettingsModal: React.FC<ChannelSettingsModalProps> = ({
  isOpen,
  onClose,
  channel,
  onChannelUpdated,
  onChannelDeleted
}) => {
  const { user } = useAuth();
  const [name, setName] = useState(channel.name);
  const [description, setDescription] = useState(channel.description || '');
  const [isPrivate, setIsPrivate] = useState(channel.is_private);
  const [loading, setLoading] = useState(false);

  const canManageChannel = user && (
    channel.creator_id === user.id ||
    LocalStorage.getMemberRole(channel.id, user.id) === 'admin'
  );

  const handleSave = async () => {
    if (!canManageChannel) return;

    setLoading(true);
    try {
      const updatedChannel = {
        ...channel,
        name: name.trim(),
        description: description.trim(),
        is_private: isPrivate
      };

      LocalStorage.updateChannel(updatedChannel);
      onChannelUpdated();
      onClose();
    } catch (error) {
      console.error('Error updating channel:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!canManageChannel) return;

    const confirmDelete = confirm(
      `Are you sure you want to delete the channel "${channel.name}"? This action cannot be undone.`
    );

    if (confirmDelete) {
      LocalStorage.deleteChannel(channel.id);
      onChannelDeleted();
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md mx-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-white flex items-center gap-2">
            <Settings className="w-6 h-6" />
            Channel Settings
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        <div className="space-y-4">
          {/* Channel Name */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Channel Name
            </label>
            <div className="relative">
              <Hash className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                disabled={!canManageChannel}
                className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed"
                required
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Description
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              disabled={!canManageChannel}
              placeholder="What's this channel about?"
              rows={3}
              className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none disabled:opacity-50 disabled:cursor-not-allowed"
            />
          </div>

          {/* Privacy Setting */}
          <div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isPrivate}
                onChange={(e) => setIsPrivate(e.target.checked)}
                disabled={!canManageChannel}
                className="w-4 h-4 rounded border-gray-600 bg-gray-700 text-purple-500 focus:ring-purple-500 focus:ring-2 disabled:opacity-50 disabled:cursor-not-allowed"
              />
              <Lock className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-300">Private Channel</span>
            </label>
            <p className="text-xs text-gray-500 mt-1 ml-6">
              Only invited members can see and join private channels
            </p>
          </div>

          {/* Channel Info */}
          <div className="p-3 bg-gray-700 rounded-lg">
            <div className="text-sm text-gray-300 space-y-1">
              <div>Created: {new Date(channel.created_at).toLocaleDateString()}</div>
              <div>Creator: {channel.creator_id === user?.id ? 'You' : 'Someone else'}</div>
              <div>Members: {LocalStorage.getChannelMembers(channel.id).length}</div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-between pt-4">
            {canManageChannel && (
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors flex items-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                Delete Channel
              </button>
            )}

            <div className="flex gap-2 ml-auto">
              <button
                onClick={onClose}
                className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
              >
                Cancel
              </button>
              {canManageChannel && (
                <button
                  onClick={handleSave}
                  disabled={loading || !name.trim()}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg transition-colors flex items-center gap-2"
                >
                  {loading ? (
                    <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                  ) : (
                    <Save className="w-4 h-4" />
                  )}
                  Save Changes
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};