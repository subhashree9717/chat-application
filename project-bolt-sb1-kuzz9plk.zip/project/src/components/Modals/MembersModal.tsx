import React, { useState, useEffect } from 'react';
import { X, User, Crown, Shield, UserMinus, MoreVertical, Users } from 'lucide-react';
import { Channel, User as UserType } from '../../types';
import { LocalStorage } from '../../lib/storage';
import { useAuth } from '../../hooks/useAuth';

interface MembersModalProps {
  isOpen: boolean;
  onClose: () => void;
  channel: Channel;
}

export const MembersModal: React.FC<MembersModalProps> = ({
  isOpen,
  onClose,
  channel
}) => {
  const { user: currentUser } = useAuth();
  const [members, setMembers] = useState<UserType[]>([]);
  const [memberRoles, setMemberRoles] = useState<Record<string, string>>({});

  useEffect(() => {
    if (isOpen) {
      loadMembers();
    }
  }, [isOpen, channel.id]);

  const loadMembers = () => {
    const channelMembers = LocalStorage.getChannelMembers(channel.id);
    const allUsers = LocalStorage.getUsers();
    
    const memberUsers = channelMembers.map(member => {
      const user = allUsers.find(u => u.id === member.user_id);
      return user;
    }).filter(Boolean) as UserType[];

    const roles = channelMembers.reduce((acc, member) => {
      acc[member.user_id] = member.role;
      return acc;
    }, {} as Record<string, string>);

    setMembers(memberUsers);
    setMemberRoles(roles);
  };

  const handleRemoveMember = (userId: string) => {
    if (confirm('Are you sure you want to remove this member?')) {
      LocalStorage.removeMemberFromChannel(channel.id, userId);
      loadMembers();
    }
  };

  const handleChangeRole = (userId: string, newRole: string) => {
    LocalStorage.updateMemberRole(channel.id, userId, newRole);
    loadMembers();
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'owner': return <Crown className="w-4 h-4 text-yellow-400" />;
      case 'admin': return <Shield className="w-4 h-4 text-blue-400" />;
      default: return null;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'owner': return 'text-yellow-400';
      case 'admin': return 'text-blue-400';
      default: return 'text-gray-400';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      case 'offline': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const canManageMembers = currentUser && (
    memberRoles[currentUser.id] === 'owner' || 
    memberRoles[currentUser.id] === 'admin'
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md mx-4 max-h-[80vh] overflow-hidden flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-white flex items-center gap-2">
            <Users className="w-6 h-6" />
            Channel Members ({members.length})
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-2">
          {members.map((member) => (
            <div key={member.id} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center overflow-hidden">
                    {member.avatar ? (
                      <img
                        src={member.avatar}
                        alt={member.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <User className="w-5 h-5 text-white" />
                    )}
                  </div>
                  <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 ${getStatusColor(member.status)} border-2 border-gray-700 rounded-full`} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-white font-medium">{member.name}</span>
                    {getRoleIcon(memberRoles[member.id])}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-400">@{member.username}</span>
                    <span className={`text-xs ${getRoleColor(memberRoles[member.id])}`}>
                      {memberRoles[member.id]}
                    </span>
                  </div>
                </div>
              </div>

              {canManageMembers && member.id !== currentUser?.id && memberRoles[member.id] !== 'owner' && (
                <div className="flex items-center gap-1">
                  <select
                    value={memberRoles[member.id]}
                    onChange={(e) => handleChangeRole(member.id, e.target.value)}
                    className="text-xs bg-gray-600 text-white rounded px-2 py-1 border-none focus:outline-none focus:ring-1 focus:ring-purple-500"
                  >
                    <option value="member">Member</option>
                    <option value="admin">Admin</option>
                  </select>
                  <button
                    onClick={() => handleRemoveMember(member.id)}
                    className="p-1 hover:bg-red-600 rounded transition-colors"
                    title="Remove member"
                  >
                    <UserMinus className="w-4 h-4 text-red-400" />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>

        {members.length === 0 && (
          <div className="text-center py-8 text-gray-400">
            No members found
          </div>
        )}
      </div>
    </div>
  );
};