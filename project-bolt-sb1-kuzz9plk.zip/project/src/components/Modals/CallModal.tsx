import React, { useState, useEffect } from 'react';
import { X, Phone, PhoneOff, Mic, MicOff, Video, VideoOff, Users, AlertCircle } from 'lucide-react';
import { useWebRTC } from '../../hooks/useWebRTC';
import { useAuth } from '../../hooks/useAuth';

interface CallModalProps {
  isOpen: boolean;
  onClose: () => void;
  callType: 'voice' | 'video';
  channelName: string;
  channelId: string;
}

export const CallModal: React.FC<CallModalProps> = ({
  isOpen,
  onClose,
  callType,
  channelName,
  channelId
}) => {
  const { user } = useAuth();
  const [callDuration, setCallDuration] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [isCallStarted, setIsCallStarted] = useState(false);

  const {
    callState,
    localVideoRef,
    remoteVideoRef,
    startCall,
    endCall,
    toggleMute,
    toggleVideo
  } = useWebRTC(channelId, user);

  // Start call when modal opens
  useEffect(() => {
    if (isOpen && !isCallStarted) {
      handleStartCall();
    }
  }, [isOpen, isCallStarted]);

  // Call duration timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (callState.isConnected) {
      interval = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [callState.isConnected]);

  const handleStartCall = async () => {
    try {
      setError(null);
      setIsCallStarted(true);
      await startCall(callType);
    } catch (error: any) {
      console.error('Error starting call:', error);
      
      let errorMessage = 'Unable to start call. ';
      
      if (error.name === 'NotFoundError') {
        errorMessage += callType === 'video' 
          ? 'Camera or microphone not found. Please ensure your devices are connected.'
          : 'Microphone not found. Please ensure a microphone is connected.';
      } else if (error.name === 'NotAllowedError') {
        errorMessage += callType === 'video'
          ? 'Camera and microphone access denied. Please allow permissions and try again.'
          : 'Microphone access denied. Please allow microphone permissions and try again.';
      } else if (error.name === 'NotReadableError') {
        errorMessage += callType === 'video'
          ? 'Camera or microphone is already in use by another application.'
          : 'Microphone is already in use by another application.';
      } else {
        errorMessage += 'Please check your device settings and try again.';
      }
      
      setError(errorMessage);
      setIsCallStarted(false);
    }
  };

  const handleEndCall = () => {
    endCall();
    setCallDuration(0);
    setIsCallStarted(false);
    onClose();
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-gray-900 rounded-lg p-6 w-full max-w-4xl mx-4 min-h-[500px] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-semibold text-white flex items-center gap-2">
              {callType === 'voice' ? <Phone className="w-6 h-6" /> : <Video className="w-6 h-6" />}
              {callType === 'voice' ? 'Voice Call' : 'Video Call'}
            </h2>
            <p className="text-gray-400">#{channelName}</p>
          </div>
          <button
            onClick={handleEndCall}
            className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-4 p-4 bg-red-900/50 border border-red-700 rounded-lg flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-red-200 text-sm">{error}</p>
            </div>
            <button
              onClick={() => setError(null)}
              className="text-red-400 hover:text-red-300 transition-colors"
            >
              ×
            </button>
          </div>
        )}

        {/* Video Area */}
        <div className="flex-1 flex flex-col items-center justify-center relative">
          {callType === 'video' ? (
            <div className="w-full h-full flex gap-4">
              {/* Remote Video */}
              <div className="flex-1 bg-gray-800 rounded-lg overflow-hidden relative">
                <video
                  ref={remoteVideoRef}
                  autoPlay
                  playsInline
                  className="w-full h-full object-cover"
                />
                {!callState.remoteStream && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-2">
                        <Video className="w-8 h-8 text-gray-400" />
                      </div>
                      <p className="text-gray-400">Waiting for participant...</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Local Video */}
              <div className="w-64 h-48 bg-gray-800 rounded-lg overflow-hidden relative">
                <video
                  ref={localVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
                {callState.isVideoOff && (
                  <div className="absolute inset-0 bg-gray-800 flex items-center justify-center">
                    <VideoOff className="w-8 h-8 text-gray-400" />
                  </div>
                )}
                <div className="absolute bottom-2 left-2 text-xs text-white bg-black/50 px-2 py-1 rounded">
                  You
                </div>
              </div>
            </div>
          ) : (
            /* Voice Call UI */
            <div className="text-center">
              {callState.isConnecting ? (
                <>
                  <div className="w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                  <p className="text-white text-lg mb-2">Connecting...</p>
                  <p className="text-gray-400">Waiting for participants to join</p>
                </>
              ) : callState.isConnected ? (
                <>
                  <div className="w-24 h-24 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Phone className="w-12 h-12 text-white" />
                  </div>
                  <p className="text-white text-lg mb-2">Connected</p>
                  <p className="text-gray-400 mb-4">{formatDuration(callDuration)}</p>
                </>
              ) : (
                <>
                  <div className="w-24 h-24 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Phone className="w-12 h-12 text-white" />
                  </div>
                  <p className="text-white text-lg mb-2">Starting Call...</p>
                  <p className="text-gray-400">Setting up audio connection</p>
                </>
              )}
            </div>
          )}
        </div>

        {/* Call Status */}
        {(callState.isConnected || callState.isConnecting) && (
          <div className="mb-4 text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Users className="w-4 h-4 text-gray-400" />
              <span className="text-gray-400">
                {callState.participants.length + 1} participant{callState.participants.length !== 0 ? 's' : ''}
              </span>
            </div>
            
            {callState.isConnected && (
              <p className="text-green-400 text-sm">
                🟢 Call active • {formatDuration(callDuration)}
              </p>
            )}
          </div>
        )}

        {/* Call Controls */}
        <div className="flex items-center justify-center gap-4">
          <button
            onClick={toggleMute}
            className={`p-3 rounded-full transition-colors ${
              callState.isMuted ? 'bg-red-600 hover:bg-red-700' : 'bg-gray-700 hover:bg-gray-600'
            }`}
            title={callState.isMuted ? 'Unmute' : 'Mute'}
            disabled={!callState.localStream}
          >
            {callState.isMuted ? (
              <MicOff className="w-6 h-6 text-white" />
            ) : (
              <Mic className="w-6 h-6 text-white" />
            )}
          </button>

          {callType === 'video' && (
            <button
              onClick={toggleVideo}
              className={`p-3 rounded-full transition-colors ${
                callState.isVideoOff ? 'bg-red-600 hover:bg-red-700' : 'bg-gray-700 hover:bg-gray-600'
              }`}
              title={callState.isVideoOff ? 'Turn on camera' : 'Turn off camera'}
              disabled={!callState.localStream}
            >
              {callState.isVideoOff ? (
                <VideoOff className="w-6 h-6 text-white" />
              ) : (
                <Video className="w-6 h-6 text-white" />
              )}
            </button>
          )}

          <button
            onClick={handleEndCall}
            className="p-3 bg-red-600 hover:bg-red-700 rounded-full transition-colors"
            title="End call"
          >
            <PhoneOff className="w-6 h-6 text-white" />
          </button>
        </div>

        {/* Instructions */}
        <div className="mt-4 p-3 bg-blue-600/20 border border-blue-600/30 rounded-lg">
          <p className="text-blue-200 text-sm text-center">
            📞 Real-time calling enabled! Open this app in another tab/window to test peer-to-peer communication.
          </p>
        </div>
      </div>
    </div>
  );
};