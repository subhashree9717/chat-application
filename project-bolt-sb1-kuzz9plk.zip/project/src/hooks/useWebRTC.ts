import { useRef, useEffect, useState, useCallback } from 'react';
import { User } from '../types';

interface WebRTCConfig {
  iceServers: RTCIceServer[];
}

interface CallState {
  isConnected: boolean;
  isConnecting: boolean;
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  participants: User[];
  isMuted: boolean;
  isVideoOff: boolean;
}

export const useWebRTC = (channelId: string, currentUser: User | null) => {
  const [callState, setCallState] = useState<CallState>({
    isConnected: false,
    isConnecting: false,
    localStream: null,
    remoteStream: null,
    participants: [],
    isMuted: false,
    isVideoOff: false
  });

  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const socketRef = useRef<WebSocket | null>(null);

  const webrtcConfig: WebRTCConfig = {
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' }
    ]
  };

  // Initialize WebSocket connection for signaling
  const initializeSignaling = useCallback(() => {
    // For demo purposes, we'll simulate signaling with localStorage events
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === `webrtc_signal_${channelId}` && e.newValue) {
        const signal = JSON.parse(e.newValue);
        handleSignalingMessage(signal);
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [channelId]);

  // Send signaling message
  const sendSignalingMessage = useCallback((message: any) => {
    const signal = {
      ...message,
      from: currentUser?.id,
      timestamp: Date.now()
    };
    localStorage.setItem(`webrtc_signal_${channelId}`, JSON.stringify(signal));
    
    // Clear after a short delay to allow other tabs to receive it
    setTimeout(() => {
      localStorage.removeItem(`webrtc_signal_${channelId}`);
    }, 1000);
  }, [channelId, currentUser]);

  // Handle incoming signaling messages
  const handleSignalingMessage = useCallback(async (message: any) => {
    if (!peerConnectionRef.current || message.from === currentUser?.id) return;

    try {
      switch (message.type) {
        case 'offer':
          await peerConnectionRef.current.setRemoteDescription(message.offer);
          const answer = await peerConnectionRef.current.createAnswer();
          await peerConnectionRef.current.setLocalDescription(answer);
          sendSignalingMessage({ type: 'answer', answer });
          break;

        case 'answer':
          await peerConnectionRef.current.setRemoteDescription(message.answer);
          break;

        case 'ice-candidate':
          await peerConnectionRef.current.addIceCandidate(message.candidate);
          break;

        case 'user-joined':
          setCallState(prev => ({
            ...prev,
            participants: [...prev.participants.filter(p => p.id !== message.user.id), message.user]
          }));
          break;

        case 'user-left':
          setCallState(prev => ({
            ...prev,
            participants: prev.participants.filter(p => p.id !== message.userId)
          }));
          break;
      }
    } catch (error) {
      console.error('Error handling signaling message:', error);
    }
  }, [currentUser, sendSignalingMessage]);

  // Initialize peer connection
  const initializePeerConnection = useCallback(() => {
    const peerConnection = new RTCPeerConnection(webrtcConfig);

    peerConnection.onicecandidate = (event) => {
      if (event.candidate) {
        sendSignalingMessage({
          type: 'ice-candidate',
          candidate: event.candidate
        });
      }
    };

    peerConnection.ontrack = (event) => {
      const [remoteStream] = event.streams;
      setCallState(prev => ({ ...prev, remoteStream }));
      
      if (remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = remoteStream;
      }
    };

    peerConnection.onconnectionstatechange = () => {
      const state = peerConnection.connectionState;
      setCallState(prev => ({
        ...prev,
        isConnected: state === 'connected',
        isConnecting: state === 'connecting'
      }));
    };

    peerConnectionRef.current = peerConnection;
    return peerConnection;
  }, [sendSignalingMessage]);

  // Start call
  const startCall = useCallback(async (callType: 'voice' | 'video') => {
    try {
      setCallState(prev => ({ ...prev, isConnecting: true }));

      // Get user media
      const constraints = {
        audio: true,
        video: callType === 'video'
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      setCallState(prev => ({ ...prev, localStream: stream }));

      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }

      // Initialize peer connection
      const peerConnection = initializePeerConnection();

      // Add local stream to peer connection
      stream.getTracks().forEach(track => {
        peerConnection.addTrack(track, stream);
      });

      // Announce user joined
      if (currentUser) {
        sendSignalingMessage({
          type: 'user-joined',
          user: currentUser,
          callType
        });
      }

      // Create and send offer
      const offer = await peerConnection.createOffer();
      await peerConnection.setLocalDescription(offer);
      sendSignalingMessage({ type: 'offer', offer });

    } catch (error) {
      console.error('Error starting call:', error);
      setCallState(prev => ({ ...prev, isConnecting: false }));
      throw error;
    }
  }, [currentUser, initializePeerConnection, sendSignalingMessage]);

  // End call
  const endCall = useCallback(() => {
    // Stop local stream
    if (callState.localStream) {
      callState.localStream.getTracks().forEach(track => track.stop());
    }

    // Close peer connection
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
      peerConnectionRef.current = null;
    }

    // Announce user left
    if (currentUser) {
      sendSignalingMessage({
        type: 'user-left',
        userId: currentUser.id
      });
    }

    // Reset state
    setCallState({
      isConnected: false,
      isConnecting: false,
      localStream: null,
      remoteStream: null,
      participants: [],
      isMuted: false,
      isVideoOff: false
    });

    // Clear video elements
    if (localVideoRef.current) {
      localVideoRef.current.srcObject = null;
    }
    if (remoteVideoRef.current) {
      remoteVideoRef.current.srcObject = null;
    }
  }, [callState.localStream, currentUser, sendSignalingMessage]);

  // Toggle mute
  const toggleMute = useCallback(() => {
    if (callState.localStream) {
      const audioTrack = callState.localStream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = callState.isMuted;
        setCallState(prev => ({ ...prev, isMuted: !prev.isMuted }));
      }
    }
  }, [callState.localStream, callState.isMuted]);

  // Toggle video
  const toggleVideo = useCallback(() => {
    if (callState.localStream) {
      const videoTrack = callState.localStream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = callState.isVideoOff;
        setCallState(prev => ({ ...prev, isVideoOff: !prev.isVideoOff }));
      }
    }
  }, [callState.localStream, callState.isVideoOff]);

  // Initialize signaling on mount
  useEffect(() => {
    const cleanup = initializeSignaling();
    return cleanup;
  }, [initializeSignaling]);

  return {
    callState,
    localVideoRef,
    remoteVideoRef,
    startCall,
    endCall,
    toggleMute,
    toggleVideo
  };
};