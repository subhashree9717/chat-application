import { useState, useEffect } from 'react';
import { SimpleAuth } from '../lib/auth';
import { User } from '../types';

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing user session
    const currentUser = SimpleAuth.getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
      // Refresh user data
      SimpleAuth.refreshUser(currentUser.id).then((refreshedUser) => {
        if (refreshedUser) {
          setUser(refreshedUser);
        }
      });
    }
    setLoading(false);
  }, []);

  const signUp = async (username: string, password: string, name: string) => {
    const result = await SimpleAuth.signUp(username, password, name);
    if (result.data) {
      setUser(result.data);
    }
    return result;
  };

  const signIn = async (username: string, password: string) => {
    const result = await SimpleAuth.signIn(username, password);
    if (result.data) {
      setUser(result.data);
    }
    return result;
  };

  const signOut = async () => {
    const result = await SimpleAuth.signOut();
    setUser(null);
    return result;
  };

  return {
    user,
    loading,
    signUp,
    signIn,
    signOut
  };
};