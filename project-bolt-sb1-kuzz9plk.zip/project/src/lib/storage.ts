import { User, Channel, Message } from '../types';

interface ChannelMember {
  id: string;
  channel_id: string;
  user_id: string;
  role: 'owner' | 'admin' | 'member';
  joined_at: string;
}

export class LocalStorage {
  // Users
  static getUsers(): User[] {
    const users = localStorage.getItem('chat_users');
    return users ? JSON.parse(users) : [];
  }

  static saveUser(user: User): void {
    const users = this.getUsers();
    const existingIndex = users.findIndex(u => u.id === user.id);
    if (existingIndex >= 0) {
      users[existingIndex] = user;
    } else {
      users.push(user);
    }
    localStorage.setItem('chat_users', JSON.stringify(users));
  }

  static getUserByUsername(username: string): User | null {
    const users = this.getUsers();
    return users.find(u => u.username === username) || null;
  }

  static getUserById(id: string): User | null {
    const users = this.getUsers();
    return users.find(u => u.id === id) || null;
  }

  // Current User Session
  static getCurrentUser(): User | null {
    const user = localStorage.getItem('current_user');
    return user ? JSON.parse(user) : null;
  }

  static setCurrentUser(user: User | null): void {
    if (user) {
      localStorage.setItem('current_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('current_user');
    }
  }

  // Channels
  static getChannels(): Channel[] {
    const channels = localStorage.getItem('chat_channels');
    if (!channels) {
      // Create default channels
      const defaultChannels: Channel[] = [
        {
          id: 'general',
          name: 'general',
          description: 'General discussion',
          is_private: false,
          creator_id: 'system',
          created_at: new Date().toISOString()
        },
        {
          id: 'random',
          name: 'random',
          description: 'Random conversations',
          is_private: false,
          creator_id: 'system',
          created_at: new Date().toISOString()
        }
      ];
      this.saveChannels(defaultChannels);
      return defaultChannels;
    }
    return JSON.parse(channels);
  }

  static saveChannels(channels: Channel[]): void {
    localStorage.setItem('chat_channels', JSON.stringify(channels));
  }

  static addChannel(channel: Channel): void {
    const channels = this.getChannels();
    channels.push(channel);
    this.saveChannels(channels);
  }

  static updateChannel(channel: Channel): void {
    const channels = this.getChannels();
    const index = channels.findIndex(c => c.id === channel.id);
    if (index >= 0) {
      channels[index] = channel;
      this.saveChannels(channels);
    }
  }

  static deleteChannel(channelId: string): void {
    const channels = this.getChannels().filter(c => c.id !== channelId);
    this.saveChannels(channels);
    
    // Also remove channel members and messages
    localStorage.removeItem(`chat_channel_members_${channelId}`);
    localStorage.removeItem(`chat_messages_${channelId}`);
  }

  // Channel Members
  static getChannelMembers(channelId: string): ChannelMember[] {
    const members = localStorage.getItem(`chat_channel_members_${channelId}`);
    return members ? JSON.parse(members) : [];
  }

  static saveChannelMembers(channelId: string, members: ChannelMember[]): void {
    localStorage.setItem(`chat_channel_members_${channelId}`, JSON.stringify(members));
  }

  static addMemberToChannel(channelId: string, userId: string, role: 'owner' | 'admin' | 'member'): void {
    const members = this.getChannelMembers(channelId);
    const existingMember = members.find(m => m.user_id === userId);
    
    if (!existingMember) {
      const newMember: ChannelMember = {
        id: Date.now().toString(),
        channel_id: channelId,
        user_id: userId,
        role,
        joined_at: new Date().toISOString()
      };
      members.push(newMember);
      this.saveChannelMembers(channelId, members);
      
      // Auto-add new users to default channels
      if (channelId === 'general' || channelId === 'random') {
        // This is handled elsewhere, just ensuring consistency
      }
    }
  }

  static removeMemberFromChannel(channelId: string, userId: string): void {
    const members = this.getChannelMembers(channelId);
    const filteredMembers = members.filter(m => m.user_id !== userId);
    this.saveChannelMembers(channelId, filteredMembers);
  }

  static updateMemberRole(channelId: string, userId: string, role: string): void {
    const members = this.getChannelMembers(channelId);
    const member = members.find(m => m.user_id === userId);
    if (member) {
      member.role = role as 'owner' | 'admin' | 'member';
      this.saveChannelMembers(channelId, members);
    }
  }

  static getMemberRole(channelId: string, userId: string): string | null {
    const members = this.getChannelMembers(channelId);
    const member = members.find(m => m.user_id === userId);
    return member ? member.role : null;
  }

  // Messages
  static getMessages(channelId: string): Message[] {
    const messages = localStorage.getItem(`chat_messages_${channelId}`);
    if (!messages && channelId === 'general') {
      // Add welcome message to general channel
      const welcomeMessage: Message = {
        id: 'welcome',
        content: 'Welcome to the chat! 🎉 Start chatting with others!',
        user_id: 'system',
        channel_id: 'general',
        message_type: 'text',
        reactions: {},
        created_at: new Date().toISOString(),
        user: {
          id: 'system',
          username: 'system',
          name: 'System',
          status: 'online',
          created_at: new Date().toISOString()
        }
      };
      this.saveMessages(channelId, [welcomeMessage]);
      return [welcomeMessage];
    }
    return messages ? JSON.parse(messages) : [];
  }

  static saveMessages(channelId: string, messages: Message[]): void {
    localStorage.setItem(`chat_messages_${channelId}`, JSON.stringify(messages));
  }

  static addMessage(message: Message): void {
    const messages = this.getMessages(message.channel_id);
    messages.push(message);
    this.saveMessages(message.channel_id, messages);
  }

  static updateMessage(messageId: string, channelId: string, updates: Partial<Message>): void {
    const messages = this.getMessages(channelId);
    const index = messages.findIndex(m => m.id === messageId);
    if (index >= 0) {
      messages[index] = { ...messages[index], ...updates };
      this.saveMessages(channelId, messages);
    }
  }

  // Clear all data
  static clearAll(): void {
    const keys = Object.keys(localStorage).filter(key => key.startsWith('chat_'));
    keys.forEach(key => localStorage.removeItem(key));
    localStorage.removeItem('current_user');
  }
}