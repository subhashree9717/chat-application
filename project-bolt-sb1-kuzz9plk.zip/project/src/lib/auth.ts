import { LocalStorage } from './storage';
import { User } from '../types';

export class SimpleAuth {
  static async signUp(username: string, password: string, name: string) {
    try {
      // Check if username already exists
      const existingUser = LocalStorage.getUserByUsername(username);
      if (existingUser) {
        return { data: null, error: { message: 'Username already exists' } };
      }

      // Create new user
      const user: User = {
        id: Date.now().toString(),
        username,
        name,
        status: 'online',
        created_at: new Date().toISOString()
      };

      LocalStorage.saveUser(user);
      LocalStorage.setCurrentUser(user);
      
      // Auto-add new users to default channels
      LocalStorage.addMemberToChannel('general', user.id, 'member');
      LocalStorage.addMemberToChannel('random', user.id, 'member');
      
      return { data: user, error: null };
    } catch (error) {
      return { data: null, error };
    }
  }

  static async signIn(username: string, password: string) {
    try {
      const user = LocalStorage.getUserByUsername(username);
      if (!user) {
        return { data: null, error: { message: 'User not found' } };
      }

      // Update status to online
      user.status = 'online';
      LocalStorage.saveUser(user);
      LocalStorage.setCurrentUser(user);
      
      return { data: user, error: null };
    } catch (error) {
      return { data: null, error };
    }
  }

  static async signOut() {
    try {
      const currentUser = LocalStorage.getCurrentUser();
      if (currentUser) {
        // Update status to offline
        currentUser.status = 'offline';
        LocalStorage.saveUser(currentUser);
      }

      LocalStorage.setCurrentUser(null);
      
      return { error: null };
    } catch (error) {
      return { error };
    }
  }

  static getCurrentUser(): User | null {
    return LocalStorage.getCurrentUser();
  }

  static async refreshUser(userId: string) {
    try {
      const user = LocalStorage.getUserById(userId);
      if (user) {
        LocalStorage.setCurrentUser(user);
        return user;
      }
      return null;
    } catch {
      return null;
    }
  }

  static async updateProfile(userId: string, updates: Partial<User>) {
    try {
      const user = LocalStorage.getUserById(userId);
      if (!user) {
        return { error: { message: 'User not found' } };
      }

      const updatedUser = { ...user, ...updates };
      LocalStorage.saveUser(updatedUser);
      LocalStorage.setCurrentUser(updatedUser);

      return { data: updatedUser, error: null };
    } catch (error) {
      return { data: null, error };
    }
  }
}